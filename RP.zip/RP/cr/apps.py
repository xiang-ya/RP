from django.apps import AppConfig


class CrConfig(AppConfig):
    name = 'cr'
