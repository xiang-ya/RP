from django import forms
from .models import Post


# 给professor 做评价的学生或者评论者作评论的表格
class ProfessorForm(forms.ModelForm):
    post = forms.TextInput()

    class Meta:
        model = Post
        fields = ('post',)
