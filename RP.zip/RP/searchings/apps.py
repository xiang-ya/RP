from django.apps import AppConfig

# 这个app的名字
class SearchingsConfig(AppConfig):
    name = 'searchings'
