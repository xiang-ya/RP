from django.db import models


# 搜索相关的库，有三个方面， 包括老师，学校，学院的名字都可以用来做搜索关键字
class Search(models.Model):
    school = models.CharField(max_length=200, default='')
    prof = models.CharField(max_length=200, default='')
    college = models.CharField(max_length=100, default='')


# 招聘相关的库， 包括当前职位，姓名，邮箱， 我们的系统会自动回复邮件告知参选人我们的HR会在一日之内回复消息
class Hire(models.Model):
    job_choices = (
        ('业务员', "业务员"),
        ('数据库管理与设计', "数据库管理与设计"),
        ('后端工程师', "后端工程师"),
        ('前端工程师', "前端工程师"),
    )
    name = models.CharField(max_length=300, default='')
    email = models.EmailField(max_length=300, default='')
    job_title = models.CharField(max_length=300, choices=job_choices, default='业务员')
    message = models.TextField(max_length=500, default='')




