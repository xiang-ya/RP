from django import forms

from .models import Search, Hire


# 首页的教授学校搜索功能
class HomeForm(forms.ModelForm):
    school = forms.CharField(max_length=100, required=False)
    prof = forms.CharField(max_length=100, required=False)
    college = forms.CharField(max_length=100, required=False)

    class Meta:
        model = Search
        fields = ('school',
                  'prof',
                  'college',)


# 有关招聘的简单表格
class HireForm(forms.ModelForm):
    job_choices = (
        ('业务员', "业务员"),
        ('数据库管理与设计', "数据库管理与设计"),
        ('后端工程师', "后端工程师"),
        ('前端工程师', "前端工程师"),
    )
    name = forms.CharField(max_length=100, required=True)
    email = forms.EmailField(max_length=100, required=True)
    job_title = forms.ChoiceField(choices=job_choices)
    message = forms.TextInput()

    class Meta:
        model = Hire
        fields = ('name',
                  'email',
                  'job_title',
                  'message',)