from django.urls import path

from home.views import HomeView

# 只有一个url，网站主页的url
app_name = 'home'
urlpatterns = [
    path('', HomeView.as_view(), name='index'),
]
