from django.contrib import admin
from home.models import Hire

admin.site.register(Hire)
